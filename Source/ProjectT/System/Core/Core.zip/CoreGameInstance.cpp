﻿
// Fill out your copyright notice in the Description page of Project Settings.


#include "CoreGameInstance.h"

#include "HAL/PlatformTime.h"
#include "TimerManager.h"
#include "Blueprint/UserWidget.h"
#include "Common/AssetUtilsLibrary.h"
#include "Common/GlobalUtilsLibrary.h"
#include "ProjectT/System/Core/Managers/NotificationCenter.h"
#include "ProjectT/System/Core/Managers/OptionManager.h"
#include "ProjectT/System/Core/Managers/SoundManager.h"
#include "ProjectT/System/Core/Managers/StageManager.h"
#include "ProjectT/System/Core/Managers/CoreCheatManager.h"
#include "ProjectT/System/Core/Managers/DataDam.h"
#include "Widgets/Images/SThrobber.h"

static double GLoadingStartTime = 0.0;

UCoreGameInstance::UCoreGameInstance() :
	DataDam(nullptr),
	StageManager(nullptr),
	OptionManager(nullptr),
	SoundManager(nullptr),
	CoreCheatManager(nullptr),
    NotificationCenter(nullptr)
{
}

void UCoreGameInstance::Init()
{
	Super::Init();
	
	Execute_GetDataDam(this)->Initialize();
	
	StageManager = NewObject<UStageManager>(this);
	OptionManager = NewObject<UOptionManager>(this);
	SoundManager = NewObject<USoundManager>(this);
	CoreCheatManager = NewObject<UCoreCheatManager>(this);

	auto HideLoadingScreenLambda = [this]()
	{
		if (LoadingScreenWidget.IsValid())
		{
			if (UGameViewportClient* GameViewportClient = GetGameViewportClient())
			{
				NMT_CHECKF(GameViewportClient);
			
				GameViewportClient->RemoveViewportWidgetContent(LoadingScreenWidget.ToSharedRef());
				LoadingScreenWidget.Reset();

				GameViewportClient->bDisableWorldRendering = false;
			}
		}
	};

	PreLoadMapHandle = FCoreUObjectDelegates::PreLoadMap.AddLambda([this](const FString& /* MapName */)
	{
		const FString ClassPath = UAssetUtilsLibrary::AssetReferencePathToClassPath(TEXT("/Script/UMGEditor.WidgetBlueprint'/Game/UI/Loading/WBP_Loading.WBP_Loading'"));
		FSoftClassPath LoadingScreenWidgetPath(ClassPath);
		TSubclassOf<UUserWidget> LoadingScreenWidgetClass = LoadingScreenWidgetPath.TryLoadClass<UUserWidget>();
		if (UUserWidget* UserWidget = UUserWidget::CreateWidgetInstance(*this, LoadingScreenWidgetClass, NAME_None))
		{
			LoadingScreenWidget = UserWidget->TakeWidget();
		}
		else
		{
			LoadingScreenWidget = SNew(SThrobber);
		}
		UGameViewportClient* GameViewportClient = GetGameViewportClient();
		GameViewportClient->AddViewportWidgetContent(LoadingScreenWidget.ToSharedRef(), 1000.f);

		GLoadingStartTime = FPlatformTime::Seconds();
	});

	PostLoadMapHandle = FCoreUObjectDelegates::PostLoadMapWithWorld.AddLambda([this, HideLoadingScreenLambda](UWorld* LoadedWorld)
	{
		// 맵 로딩이 실패했거나 유효하지 않은 월드일 경우를 대비해 즉시 로딩 화면을 숨깁니다.
		if (!LoadedWorld)
		{
			HideLoadingScreenLambda();
			return;
		}

		constexpr float MinimumLoadingScreenTime = 2.0f;
		const float ElapsedTime = static_cast<float>(FPlatformTime::Seconds() - GLoadingStartTime);
		const float RemainingTime = MinimumLoadingScreenTime - ElapsedTime;

		if (RemainingTime > 0.f)
		{
			// GameInstance 자체의 TimerManager를 사용하여 타이머를 설정합니다.
			// 이 방법이 World가 유효하지 않은 상황에서도 가장 안정적입니다.
			GetTimerManager().SetTimer(DelayHandle, HideLoadingScreenLambda, RemainingTime, false);
		}
		else
		{
			HideLoadingScreenLambda();
		}
	});
	
}

void UCoreGameInstance::BeginDestroy()
{
	Super::BeginDestroy();
	FCoreUObjectDelegates::PostLoadMapWithWorld.Remove(PostLoadMapHandle);
	FCoreUObjectDelegates::PreLoadMap.Remove(PreLoadMapHandle);

	DataDam = nullptr;
	StageManager = nullptr;
	OptionManager = nullptr;
	SoundManager = nullptr;
	CoreCheatManager = nullptr;
}

UDataDam* UCoreGameInstance::GetDataDam_Implementation()
{
	if (!DataDam)
	{
		DataDam = NewObject<UDataDam>(this);
	}
	return DataDam;
}

UStageManager* UCoreGameInstance::GetStageManager_Implementation()
{
	if(!StageManager)
	{
		StageManager = NewObject<UStageManager>(this);
	}
	return StageManager;
}

UOptionManager* UCoreGameInstance::GetOptionManager_Implementation()
{
	if (!OptionManager->IsValidLowLevel())
	{
		OptionManager = NewObject<UOptionManager>(this);
	}
	return OptionManager;
}

USoundManager* UCoreGameInstance::GetSoundManager_Implementation()
{
	if (!SoundManager->IsValidLowLevel())
	{
		SoundManager = NewObject<USoundManager>(this);
	}
	return SoundManager;
}

UCoreCheatManager* UCoreGameInstance::GetCoreCheatManager_Implementation()
{
	if(!CoreCheatManager->IsValidLowLevel())
	{
		CoreCheatManager = NewObject<UCoreCheatManager>(this);
	}
	return CoreCheatManager;
}

UNotificationCenter* UCoreGameInstance::GetNotificationCenter_Implementation()
{
	if(!NotificationCenter)
	{
		NotificationCenter = NewObject<UNotificationCenter>(this);
	}
	return NotificationCenter;
}

bool UCoreGameInstance::IsRunningInDevelopment()
{
	EBuildTargetType BT = FApp::GetBuildTargetType();
	EBuildConfiguration BC = FApp::GetBuildConfiguration();
	
	if(BT == EBuildTargetType::Editor) return true; 
	else if(BT == EBuildTargetType::Game && BC == EBuildConfiguration::DebugGame) return true;
	else if(BT == EBuildTargetType::Game && BC == EBuildConfiguration::Development) return true;
	else return false;
}
